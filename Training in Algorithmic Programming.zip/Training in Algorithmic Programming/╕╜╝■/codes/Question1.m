% Fluid parameters
density_fluid = 1.0;       % Fluid density [kg/m³]
U_max = 5;                 % Maximum centerline velocity [m/s]

% Particle parameters
radius = 0.01;             % Particle radius [m]
density_particle = 2.8;    % Particle density [kg/m³]
mass = (4/3) * pi * (radius^3) * (density_particle - density_fluid); % Particle mass [kg]
area = pi * (radius^2);    % Cross-sectional area [m²]

% Drag coefficient
C_d = 0.50;                % Dimensionless drag coefficient

% Gravity
g = 9.81;                  % Gravitational acceleration [m/s²]

% Time parameters
dt = 0.01;                 % Time step size [s]
total_time = 1000;         % Total simulation time [s]
num_steps = round(total_time / dt); % Number of time steps
sample_rate = 4;     

% Initial conditions
initial_position_1 = [2.5; 1.0];   % IC1: [x; y] [m]
initial_velocity_1 = [0.0; -1.0];  % IC1: [vx; vy] [m/s]
initial_positions_2 = [0.0, 0.40; 0.0, 0.0; 0.0, -0.40]; % IC2 positions [m]
initial_velocity_2 = [1.6; 0.0];   % IC2 velocity [m/s]

% Fluid velocity profile
fluid_velocity = @(y) [U_max * (1 - y^2); 0];

% Drag force calculation
drag_force = @(v_particle, v_fluid) ...
    0.5 * C_d * density_fluid * norm(v_fluid - v_particle) * ...
    (v_fluid - v_particle) * area;

% ===== Simulation =====
% IC1 Simulation
positions_1 = zeros(2, num_steps + 1);
positions_1(:, 1) = initial_position_1;
velocity = initial_velocity_1;

for t = 1:num_steps
    v_fluid = fluid_velocity(positions_1(2, t));
    drag = drag_force(velocity, v_fluid);
    gravity = [0; -mass * g];
    acceleration = (drag + gravity) / mass;
    velocity = velocity + acceleration * dt;
    positions_1(:, t + 1) = positions_1(:, t) + velocity * dt;
    
    % Boundary condition
    if abs(positions_1(2, t + 1)) > 1
        positions_1(2, t + 1) = sign(positions_1(2, t + 1)) * 1;
        velocity(2) = -0.5 * velocity(2); % Partial bounce
    end
end

% IC2 Simulation (3 particles)
trajectories_2 = cell(3, 1);
for i = 1:3
    pos_traj = zeros(2, num_steps + 1);
    pos_traj(:, 1) = initial_positions_2(i, :)';
    velocity = initial_velocity_2;
    
    for t = 1:num_steps
        v_fluid = fluid_velocity(pos_traj(2, t));
        drag = drag_force(velocity, v_fluid);
        gravity = [0; -mass * g];
        velocity = velocity + ((drag + gravity) / mass) * dt;
        pos_traj(:, t + 1) = pos_traj(:, t) + velocity * dt;
        
        % Boundary condition
        if abs(pos_traj(2, t + 1)) > 1
            pos_traj(2, t + 1) = sign(pos_traj(2, t + 1)) * 1;
            velocity(2) = -0.5 * velocity(2); % Partial bounce
        end
    end
    trajectories_2{i} = pos_traj;
end

% ===== Trajectory Plot =====
figure;
hold on;

% Plot IC1 trajectory as dots
scatter(positions_1(1,1:sample_rate:end), positions_1(2,1:sample_rate:end), ...
    20, 'filled', 'MarkerFaceColor', [0 0.447 0.741], 'DisplayName', 'IC1: (2.5,0)');

% Plot IC2 trajectories as dots (3 particles)
colors = [1 0 0; 0 0.5 0; 0 0 1]; % Red, Green, Blue
labels = {'IC2: (0,0.4)', 'IC2: (0,0)', 'IC2: (0,-0.4)'};
for i = 1:3
    traj = trajectories_2{i};
    scatter(traj(1,1:sample_rate:end), traj(2,1:sample_rate:end), ...
        20, 'filled', 'MarkerFaceColor', colors(i,:), 'DisplayName', labels{i});
end

% Channel boundaries
yline(1, 'k--', 'LineWidth', 1.2);
yline(-1, 'k--', 'LineWidth', 1.2);

% Formatting
xlabel('x Position [m]', 'FontSize', 12);
ylabel('y Position [m]', 'FontSize', 12);
title('Particle Trajectories in Channel Flow', 'FontSize', 14);
legend('Location', 'northeast', 'FontSize', 10);
grid on;
axis equal;
xlim([0, 10]);
ylim([-1.2, 1.2]);
set(gca, 'FontSize', 10);
box on;
hold off;