% Define parameters
r_h = 0.025; % Radius of the hole, in meters
y_0 = 2.5; % Initial height of the liquid, in meters
g = 9.81; % Acceleration due to gravity, in m/s^2
t_end = 3000; % Total simulation time, in seconds
dt = 0.1; % Time step, in seconds

% Define the function t(y)
t_y = @(y) (1 / r_h^2/sqrt(2*9.81)) * (8 * (y_0^(1/2) - y.^(1/2)) - (4/3) * (y_0^(3/2) - y.^(3/2)) + (1/10) * (y_0^(5/2) - y.^(5/2)));

% Define the differential equation
dydt = @(t,y) - (sqrt(2*g*y) * r_h^2) / (2 - 0.5*y)^2;

% Set up the time array
tspan = 0:dt:t_end; % From 0 to 3000 seconds, with a step size of 0.1 seconds

% Solve the differential equation using ode45
options = odeset('RelTol',1e-6);
[t_ode, y_ode] = ode45(dydt, tspan, y_0, options);

% Calculate the theoretical values t(y)
y_values = linspace(0.001, y_0, 1000); % From 0 to initial height
t_values = t_y(y_values);

% Plot the graph
figure;
plot(t_ode, y_ode, 'b-', 'LineWidth', 2); % ode45 results
hold on;
plot(t_values, y_values, 'r--', 'LineWidth', 2); % Theoretical curve
hold off;

% Format the plot
xlabel('Time (s)', 'FontSize', 12);
ylabel('Liquid Height y (m)', 'FontSize', 12);
title('Comparison of Liquid Height vs Time', 'FontSize', 14);
legend('ode45 Simulation', 'Theoretical Curve', 'Location', 'best');
grid on;
set(gca, 'FontSize', 11);

% Calculate and plot the difference
figure;
diff_y = y_ode - interp1(t_values, y_values, t_ode);
plot(t_ode, diff_y, 'LineWidth', 2, 'Color', 'magenta'); 
xlabel('Time (s)', 'FontSize', 12);
ylabel('Difference in Liquid Height (m)', 'FontSize', 12);
title('Difference Between Simulation and Theory', 'FontSize', 14);
grid on;
set(gca, 'FontSize', 11);