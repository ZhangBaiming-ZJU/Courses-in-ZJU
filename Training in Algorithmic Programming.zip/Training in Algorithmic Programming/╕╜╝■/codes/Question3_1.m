% 定义参数
r_h = 0.025; % 圆孔半径，单位：米
y_0 = 2.5; % 初始液体高度，单位：米

% 定义函数 t(y)
t_y = @(y) (1 / sqrt(2*9.81)/r_h^2) * (8 * (y_0^(1/2) - y.^(1/2)) - (4/3) * (y_0^(3/2) - y.^(3/2)) + (1/10) * (y_0^(5/2) - y.^(5/2)));

% 定义 y 的范围，从 0 到 2.5 米
y_values = linspace(0.01, 2.5, 10000); % 从 0 开始到 2.5 米

% 计算对应的 t 值
t_values = t_y(y_values);

% 绘制图像
figure;
plot(t_values, y_values, 'LineWidth', 2);
xlabel('Time t (s)');
ylabel('Liquid Height y (m)');
title('Time as a Function of Liquid Height');
grid on;