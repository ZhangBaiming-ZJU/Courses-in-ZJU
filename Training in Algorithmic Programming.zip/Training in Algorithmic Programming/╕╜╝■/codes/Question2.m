function state = ComputeTrajectory(dt, timesteps)
    % Initialize state matrix (2 rows x timesteps columns)
    state = zeros(2, timesteps);
    
    % Initial position at origin (0,0)
    x = 0;
    y = 0;
    
    for k = 1:timesteps
        t = (k-1) * dt;  % Current simulation time
        
        % --- 4th-order Runge-Kutta method ---
        % k1: velocity at beginning of time step
        k1_x = cos(6 * t);
        k1_y = sin(6 * t);
        
        % k2: velocity at midpoint using k1 
        x_temp = x + (dt/2) * k1_x;
        y_temp = y + (dt/2) * k1_y;
        k2_x = cos(6 * (t + dt/2)); 
        k2_y = sin(6 * (t + dt/2));
        
        % k3: improved midpoint velocity using k2 
        x_temp = x + (dt/2) * k2_x;
        y_temp = y + (dt/2) * k2_y;
        k3_x = cos(6 * (t + dt/2));
        k3_y = sin(6 * (t + dt/2));
        
        % k4: velocity at end of time step using k3 
        x_temp = x + dt * k3_x;
        y_temp = y + dt * k3_y;
        k4_x = cos(6 * (t + dt));
        k4_y = sin(6 * (t + dt));
        
        % Update position using weighted average of k1-k4
        x = x + (dt/6) * (k1_x + 2*k2_x + 2*k3_x + k4_x);
        y = y + (dt/6) * (k1_y + 2*k2_y + 2*k3_y + k4_y);
        
        % Store current state
        state(:, k) = [x; y];
    end
end

% Test script
dt = 0.005;           % Time step size (seconds)
timesteps = 2000;     % Number of time steps

% Compute trajectory
trajectory = ComputeTrajectory(dt, timesteps);

% Extract x and y coordinates
x = trajectory(1, :);
y = trajectory(2, :);

% Plot trajectory
figure;
plot(x, y, 'b-', 'LineWidth', 1.5);
xlabel('x position');
ylabel('y position');
title('Particle Trajectory: y vs x');
grid on;
axis equal;           % Equal scaling for x and y axes

% Mark starting point
hold on;
plot(0, 0, 'ro', 'MarkerSize', 8, 'MarkerFaceColor', 'r');
hold off;
legend('Trajectory', 'Start Point (0,0)');