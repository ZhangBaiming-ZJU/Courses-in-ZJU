% watertank.m - Simulation of Liquid Drainage from an Inverted Conical Tank
clear; clc; close all;

%% 1. Parameter Settings
r_h = 0.025;       % Radius of the bottom orifice (m)
g = 9.81;          % Gravitational acceleration (m/s^2)
y0 = 2.5;          % Initial liquid height (m)
t_end = 3000;      % Total simulation time (s)
dt = 0.1;          % Time step (s)

%% 2. Define the Differential Equation (Anonymous Function)
% According to Torricelli's theorem and the given differential equation form
% dy/dt = - (sqrt(2*g*y) * r_h^2) / (2 - 0.5*y)^2
% The negative sign indicates decreasing height over time
dydt = @(t,y) - (sqrt(2*g*y) * r_h^2) / (2 - 0.5*y)^2;

%% 3. Time Array Setup
tspan = 0:dt:t_end; % From 0 to 3000s with step size 0.1s

%% 4. Solve the Differential Equation Using ode45
% Set relative tolerance for improved accuracy
options = odeset('RelTol',1e-6);
[t, y] = ode45(dydt, tspan, y0, options);

% Convert output to column vectors
t = t(:);
y = y(:);

%% 5. Find When Liquid Height First Falls Below 0.1m
empty_index = find(y < 0.1, 1);
if isempty(empty_index)
    empty_index = length(t);
    warning('Liquid did not drain below 0.1m within simulation time');
else
    fprintf('Time when liquid height first falls below 0.1m: %.1f seconds\n', t(empty_index));
end

%% 6. Plot Liquid Height vs Time
figure;
plot(t(1:empty_index), y(1:empty_index), 'LineWidth', 2);
hold on;
plot(t(empty_index), y(empty_index), 'ro', 'MarkerSize', 8); % Mark drainage point
hold off;

% Plot formatting
xlabel('Time (s)', 'FontSize', 12);
ylabel('Liquid Height y (m)', 'FontSize', 12);
title('Liquid Height vs Time in Inverted Conical Tank', 'FontSize', 14);
grid on;
set(gca, 'FontSize', 11);

% Add annotation
annotation('textbox', [0.6, 0.7, 0.2, 0.1], 'String', ...
    sprintf('Drainage time: %.1f s', t(empty_index)), ...
    'FitBoxToText', 'on', 'BackgroundColor', 'white');

